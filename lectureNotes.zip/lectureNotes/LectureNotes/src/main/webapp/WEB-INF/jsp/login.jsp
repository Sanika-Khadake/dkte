<%@ page language="java"
contentType="text/html; charset=UTF-8"
pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>LectureNote AI</title>

<link rel="stylesheet"
href="/css/style.css">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
rel="stylesheet">

</head>

<body>

<div class="main-container">

    <div class="left-panel">

        <h1>LectureNote AI</h1>

        <p>
            AI-powered platform for
            smart notes, quizzes,
            and mock interviews.
        </p>

    </div>

    <div class="right-panel">

        <div class="form-card">

            <h2>Login</h2>

            <form action="/dashboard">

                <input type="email"
                placeholder="Enter Email">

                <input type="password"
                placeholder="Enter Password">

                <button type="submit">
                    Login
                </button>

            </form>

            <p>
                Don't have account?
                <a href="/register">
                    Register
                </a>
            </p>

        </div>

    </div>

</div>

</body>
</html>