<%@ page language="java"
contentType="text/html; charset=UTF-8"
pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>LectureNote AI</title>

<link rel="stylesheet"
href="/css/style.css">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
rel="stylesheet">

</head>

<body>

<!-- NAVBAR -->

<nav class="navbar">

    <div class="logo">

        LectureNote AI

    </div>

    <ul>

        <li>
            <a href="/">Home</a>
        </li>

        <li>
            <a href="/login">Login</a>
        </li>

        <li>
            <a href="/register">Register</a>
        </li>

    </ul>

</nav>

<!-- HERO SECTION -->

<section class="hero">

    <div class="hero-left">

        <h1>
            Smart AI Platform
            for Students
        </h1>

        <p>

            Generate lecture notes,
            create quizzes,
            practice mock interviews,
            and track learning history
            using AI.

        </p>

        <div class="hero-buttons">

            <a href="/register">

                <button class="primary-btn">
                    Get Started
                </button>

            </a>

            <a href="/login">

                <button class="secondary-btn">
                    Login
                </button>

            </a>

        </div>

    </div>

    <div class="hero-right">

        <div class="hero-card">

            <h2>📚 Generate Notes</h2>

            <p>
                Convert lecture audio
                into AI-powered notes.
            </p>

        </div>

        <div class="hero-card">

            <h2>🧠 Quiz Generator</h2>

            <p>
                Upload PDF and generate
                smart quizzes instantly.
            </p>

        </div>

        <div class="hero-card">

            <h2>💼 Mock Interview</h2>

            <p>
                Practice interview
                questions using AI.
            </p>

        </div>

    </div>

</section>

<!-- FEATURES -->

<section class="features">

    <h1>Why Choose LectureNote AI?</h1>

    <div class="feature-container">

        <div class="feature-box">

            <h2>⚡ Fast AI Processing</h2>

            <p>
                Generate notes and quizzes
                in seconds.
            </p>

        </div>

        <div class="feature-box">

            <h2>📄 PDF Support</h2>

            <p>
                Upload PDF files and
                generate learning content.
            </p>

        </div>

        <div class="feature-box">

            <h2>🎯 Student Friendly</h2>

            <p>
                Modern UI designed
                specially for students.
            </p>

        </div>

    </div>

</section>

<!-- FOOTER -->

<footer class="footer">

    <p>
        © 2026 LectureNote AI.
        All Rights Reserved.
    </p>

</footer>

</body>
</html>