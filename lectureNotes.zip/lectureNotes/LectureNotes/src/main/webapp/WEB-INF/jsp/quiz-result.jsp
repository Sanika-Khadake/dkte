<%@ page contentType="text/html;charset=UTF-8" %>

<html>

<head>

<title>Quiz Result</title>

<link rel="stylesheet"
      href="/css/quiz.css">

</head>

<body>

<div class="container">

<h1>Quiz Completed</h1>

<div class="score-box">

Your Score

<h2>${score} / 5</h2>

</div>

<a href="/quiz">

<button>
Try Another Quiz
</button>

</a>

</div>

</body>

</html>