<%@ page contentType="text/html;charset=UTF-8" %>

<html>

<head>

<title>AI Quiz Generator</title>

<link rel="stylesheet"
      href="/css/quiz.css">

</head>

<body>

<div class="container">

<h1>AI Quiz Generator</h1>

<form action="/quiz/generate"
      method="post"
      enctype="multipart/form-data">

<input type="file"
       name="pdfFile"
       accept=".pdf"
       required>

<button type="submit">
Generate Quiz
</button>

</form>

</div>

</body>

</html>