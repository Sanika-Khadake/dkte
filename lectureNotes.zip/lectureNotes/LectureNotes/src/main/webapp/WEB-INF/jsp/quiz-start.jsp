<%@ page contentType="text/html;charset=UTF-8" %>

<html>

<head>

<title>Quiz Started</title>

<link rel="stylesheet"
      href="/css/quiz.css">

<script>

let timeLeft = 60;
let score = 0;

function startTimer() {

    let timer =
    setInterval(function(){

        document.getElementById("timer")
        .innerHTML =
        "Time Left: " + timeLeft;

        timeLeft--;

        if(timeLeft < 0){

            clearInterval(timer);

            submitQuiz();
        }

    },1000);
}

function submitQuiz(){

    document.getElementById("score")
    .value = Math.floor(Math.random()*5)+1;

    document.getElementById("quizForm")
    .submit();
}

window.onload = startTimer;

</script>

</head>

<body>

<div class="container">

<h1>Quiz Started</h1>

<h2 id="timer"></h2>

<div class="quiz-box">

<pre>${quiz}</pre>

</div>

<form id="quizForm"
      action="/quiz/submit"
      method="post">

<input type="hidden"
       id="score"
       name="score">

<button type="button"
        onclick="submitQuiz()">

Submit Quiz

</button>

</form>

</div>

</body>

</html>