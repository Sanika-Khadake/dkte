<%@ page language="java"
contentType="text/html; charset=UTF-8"
pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Dashboard</title>

<link rel="stylesheet"
href="/css/style.css">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
rel="stylesheet">

</head>

<body>

<div class="dashboard-container">

    <div class="sidebar">

        <h2>LectureNote AI</h2>

        <ul>

            <li>Dashboard</li>
            <li>Generate Notes</li>
            <li>Quiz Generator</li>
            <li>Mock Interview</li>
            <li>History</li>
            <li>Logout</li>

        </ul>

    </div>

    <div class="main-content">

        <div class="topbar">

            <h1>Dashboard</h1>

        </div>

        <div class="cards-container">

            <div class="dashboard-card">

                <h2>Generate Notes</h2>

                <p>
                    Convert lecture audio
                    into AI notes.
                </p>

				<a href="/generate-notes">

				    <button>
				        Open
				    </button>

				</a>

            </div>

            <div class="dashboard-card">

                <h2>Quiz Generator</h2>

                <p>
                    Generate quizzes
                    from uploaded PDF.
                </p>
				<a href="/quiz">

								    <button>
								        Open
								    </button>

								</a>
                </button>

            </div>

            <div class="dashboard-card">

                <h2>Mock Interview</h2>

                <p>
                    Practice interview
                    questions using AI.
                </p>

                <button>
                    Open
                </button>

            </div>

            <div class="dashboard-card">

                <h2>History</h2>

                <p>
                    View previous
                    activities.
                </p>

                <button>
                    Open
                </button>

            </div>

        </div>

    </div>

</div>

</body>
</html>