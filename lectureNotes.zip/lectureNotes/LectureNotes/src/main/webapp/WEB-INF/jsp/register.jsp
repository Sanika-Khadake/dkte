<%@ page language="java"
contentType="text/html; charset=UTF-8"
pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Register</title>

<link rel="stylesheet"
href="/css/style.css">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
rel="stylesheet">

</head>

<body>

<div class="main-container">

    <div class="left-panel">

        <h1>LectureNote AI</h1>

        <p>
            Generate notes,
            quizzes and interviews
            using AI.
        </p>

    </div>

    <div class="right-panel">

        <div class="form-card">

            <h2>Create Account</h2>

            <form action="/login">

                <input type="text"
                placeholder="Enter Name">

                <input type="email"
                placeholder="Enter Email">

                <input type="password"
                placeholder="Enter Password">

                <button type="submit">
                    Register
                </button>

            </form>

            <p>
                Already have account?
                <a href="/login">
                    Login
                </a>
            </p>

        </div>

    </div>

</div>

</body>
</html>