package com.lecturenotes.service;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.api.gax.core.FixedCredentialsProvider;
import com.google.cloud.speech.v2.*;
import com.google.protobuf.ByteString;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Service
public class AudioService {

    public String convertAudioToText(MultipartFile file)
            throws IOException {

        // Load Google Credentials JSON
        GoogleCredentials credentials =
                GoogleCredentials.fromStream(
                        getClass().getResourceAsStream(
                                "/google-credentials.json"));

        // Create Speech Settings
        SpeechSettings speechSettings =
                SpeechSettings.newBuilder()
                        .setCredentialsProvider(
                                FixedCredentialsProvider.create(credentials))
                        .build();

        // Create Speech Client
        try (SpeechClient speechClient =
                     SpeechClient.create(speechSettings)) {

            // Convert audio to bytes
            ByteString audioBytes =
                    ByteString.copyFrom(file.getBytes());

            // Recognition config
            RecognitionConfig recognitionConfig =
                    RecognitionConfig.newBuilder()
                            .setAutoDecodingConfig(
                                    AutoDetectDecodingConfig
                                            .newBuilder()
                                            .build())
                            .build();

            // Replace with your Google Project ID
            String recognizer =
                    "projects/lecturenotesai-496006/locations/global/recognizers/_";

            // Create request
            RecognizeRequest request =
                    RecognizeRequest.newBuilder()
                            .setRecognizer(recognizer)
                            .setConfig(recognitionConfig)
                            .setContent(audioBytes)
                            .build();

            // Get response
            RecognizeResponse response =
                    speechClient.recognize(request);

            StringBuilder transcript =
                    new StringBuilder();

            for (SpeechRecognitionResult result
                    : response.getResultsList()) {

                if (result.getAlternativesCount() > 0) {

                    transcript.append(
                            result.getAlternatives(0)
                                    .getTranscript());

                    transcript.append(" ");
                }
            }

            return transcript.toString();
        }
    }
}