package com.lecturenotes.service;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Service
public class GeminiService {

    private final String API_KEY =
            "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";

    public String generateNotes(String lectureText) {

        WebClient client = WebClient.create();

        String prompt = """
        		Create clean study notes with:
        		1. Headings
        		2. Important points
        		3. Summary

        		Lecture:
        		""" + lectureText;

        JSONObject textPart = new JSONObject();
        textPart.put("text", prompt);

        JSONArray partsArray = new JSONArray();
        partsArray.put(textPart);

        JSONObject content = new JSONObject();
        content.put("parts", partsArray);

        JSONArray contentsArray = new JSONArray();
        contentsArray.put(content);

        JSONObject body = new JSONObject();
        body.put("contents", contentsArray);

        String response = client.post()
                .uri("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key="
                        + API_KEY)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body.toString())
                .retrieve()
                .bodyToMono(String.class)
                .block();

        JSONObject json =
                new JSONObject(response);

        return json
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text");
    }
}