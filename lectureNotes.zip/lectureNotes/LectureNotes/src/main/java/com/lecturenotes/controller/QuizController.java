package com.lecturenotes.controller;

import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.multipart.MultipartFile;

import com.lecturenotes.service.GeminiService;

@Controller
@RequestMapping("/quiz")
public class QuizController {

    @Autowired
    private GeminiService geminiService;

//    @GetMapping
//    public String quizPage() {
//        return "quiz";
//    }

    @PostMapping("/generate")
    public String generateQuiz(
            @RequestParam("pdfFile") MultipartFile file,
            Model model) throws IOException {

        // CREATE FOLDER
        File folder = new File("quizuploads");

        if (!folder.exists()) {
            folder.mkdirs();
        }

        // SAVE PDF
        String filePath =
                "quizuploads/" + file.getOriginalFilename();

        file.transferTo(new File(filePath));

        // READ PDF
        PDDocument document =
                PDDocument.load(new File(filePath));

        PDFTextStripper stripper =
                new PDFTextStripper();

        String pdfText =
                stripper.getText(document);

        document.close();

        // LIMIT TEXT
        if (pdfText.length() > 3000) {
            pdfText = pdfText.substring(0, 3000);
        }

        // AI QUIZ GENERATION
        String aiQuiz =
                geminiService.generateQuiz(pdfText);

        model.addAttribute("quiz", aiQuiz);

        return "quiz-start";
    }

    @PostMapping("/submit")
    public String submitQuiz(

            @RequestParam("score")
            int score,

            Model model) {

        model.addAttribute("score", score);

        return "quiz-result";
    }
}