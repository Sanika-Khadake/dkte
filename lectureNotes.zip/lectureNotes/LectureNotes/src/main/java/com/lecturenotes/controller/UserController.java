package com.lecturenotes.controller;

import com.lecturenotes.entity.User;
import com.lecturenotes.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")

@CrossOrigin("*")

public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public User register(
            @RequestBody User user) {

        return userService.register(user);
    }

    @PostMapping("/login")
    public User login(
            @RequestParam String email,
            @RequestParam String password) {

        return userService.login(email, password);
    }
}