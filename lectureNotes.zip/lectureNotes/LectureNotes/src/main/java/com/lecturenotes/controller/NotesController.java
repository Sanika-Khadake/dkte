package com.lecturenotes.controller;

import com.lecturenotes.service.AudioService;
import com.lecturenotes.service.GeminiService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping("/notes")

public class NotesController {

    @Autowired
    private AudioService audioService;

    @Autowired
    private GeminiService geminiService;

    @GetMapping
    public String notesPage() {
        return "generate-notes";
    }

    @PostMapping("/upload")
    public String uploadAudio(
            @RequestParam("audioFile") MultipartFile file,
            Model model) {

        try {

            // AUDIO -> TEXT
            String lectureText =
                    audioService.convertAudioToText(file);

            // TEXT -> NOTES
            String notes =
                    geminiService.generateNotes(lectureText);

            model.addAttribute("notes", notes);

        } catch (Exception e) {
            model.addAttribute("notes",
                    "Error: " + e.getMessage());
        }

        return "notes-result";
    }
}